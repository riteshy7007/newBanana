// Made by Ciprian Stanciu since 2018

#pragma once

#include "Modules/ModuleManager.h"
#include <functional>
#include "EditorStyleSet.h"
#include "Module.generated.h"

UENUM()
enum class RenderPipeline : uint8
{
	RP_BUILTIN UMETA( DisplayName = "Built In Render Pipeline" ),
	RP_URP UMETA( DisplayName = "Universal Render Pipeline" ),
	RP_HDRP UMETA( DisplayName = "HD Render Pipeline" ),
};
UENUM()
enum class SkinnedMeshOptionsEnum : uint8
{
	SMO_EXPORT_AS_STATIC UMETA( DisplayName = "Export As Static Mesh" ),
	SMO_EXPORT_AS_SKINNED UMETA( DisplayName = "Export As Skinned Mesh" ),
};
UENUM()
enum class NaniteOptionsEnum : uint8
{
	NANITE_COARSE_MESH UMETA( DisplayName = "Export Coarse Mesh" ),
	NANITE_ORIGINAL_MESH UMETA( DisplayName = "Export Original Mesh" ),
};
UENUM()
enum class TangentToWorldLocationType : uint8
{
	TTWL_KEEP_UNITY_VECTORS UMETA( DisplayName = "Keep Unity Vectors" ),
	TTWL_KEEP_UNITY_VECTORS_NO_WORLDNORMALCOPY UMETA( DisplayName = "Keep Unity Vectors + No WorldNormalCopy" ),
	TTWL_BEFORE_NORMAL_CALCULATION UMETA( DisplayName = "Flip YZ Before Normals" ),
	TTWL_AFTER_NORMAL_CALCULATION UMETA( DisplayName = "Flip YZ After Normals" )
};
UENUM()
enum class FoliageExportType : uint8
{
	FET_CREATE_GAMEOBJECTS UMETA( DisplayName = "Create GameObject Per Instance" ),
	FET_USE_TREEINSTANCES UMETA( DisplayName = "Tree Instances(requires extra step in Unity)" )
};
UENUM()
enum class EngineType : uint8
{
	UNITY UMETA( DisplayName = "Unity" ),
	GODOT UMETA( DisplayName = "Godot" )
};
UENUM()
enum class ShadersType : uint8
{
	ST_CUSTOM_SHADERS UMETA( DisplayName = "CustomShaders(designed for accuracy)" ),
	ST_STANDARD_SHADERS UMETA( DisplayName = "Standard Shaders" )
};
UCLASS( config = EditorPerProjectUserSettings, MinimalAPI, BlueprintType )
class UParamsStructure : public UObject
{
	GENERATED_BODY()
public:
	

	UParamsStructure();
	UPROPERTY( EditAnywhere, BlueprintReadWrite, config )
	EngineType Engine;
	UPROPERTY( EditAnywhere, BlueprintReadWrite, config )
	RenderPipeline ScriptableRenderPipeline;
	UPROPERTY( EditAnywhere, BlueprintReadWrite, config )
	FString OutputDirectory;
	UPROPERTY( EditAnywhere, BlueprintReadWrite, config )
	ShadersType Shaders;
	UPROPERTY( EditAnywhere, BlueprintReadWrite, config )
	bool ShowFBXExportDialog;
	UPROPERTY( EditAnywhere, BlueprintReadWrite, config )
	bool ExportVertexShader;
	UPROPERTY( EditAnywhere, BlueprintReadWrite, config )
	bool ExportLODs;
	UPROPERTY( EditAnywhere, BlueprintReadWrite, config )
	bool ExportVertexColors;
	UPROPERTY( EditAnywhere, BlueprintReadWrite, config )
	bool ExportBrushes;
	UPROPERTY( EditAnywhere, BlueprintReadWrite, config )
	SkinnedMeshOptionsEnum SkinnedMeshes;
	UPROPERTY( EditAnywhere, BlueprintReadWrite, config )
	NaniteOptionsEnum NaniteOptions;
	UPROPERTY( EditAnywhere, BlueprintReadWrite, config )
	TangentToWorldLocationType TangentToWorldLocation;
	UPROPERTY( EditAnywhere, BlueprintReadWrite, config )
	bool ExportAllAnimations;
	UPROPERTY( EditAnywhere, BlueprintReadWrite, config )
	FoliageExportType FoliageExport;
	UPROPERTY( EditAnywhere, BlueprintReadWrite, config )
	bool ExportAllSounds;
	UPROPERTY( EditAnywhere, BlueprintReadWrite, config )
	bool UsePrefabs;
};

extern UParamsStructure* UTUSettings;
class UDynamicMeshComponent;
class UProceduralMeshComponent;

class FUnrealToUnityModule : public IModuleInterface
{
public:

	/** IModuleInterface implementation */
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;

	void BindEditorCommands();
	void AddCustomMenu( FToolBarBuilder& ToolbarBuilder );
	TSharedRef<SWidget> CreateMenuContent();
	void Export();
	static void DoExport( RenderPipeline Pipeline, FString OutputFolder );
	static void RemoveVirtualTextures();
	static void DoRemoveNanite();
	static void RemoveRVTs();
	static void ExportRVTTextures();
	static void RemoveVertexInterpolators();
	static void RemoveUnsupportedMaterialNodes();
		static void RemoveDitherTemporalAA();
		static void RemoveParallaxMapping();
	static void MoveFoliageToActors();
	static void FixVolumeMaterials();
	static void ConvertISMToActors();
	static void ConvertGeometryCachesToStaticMeshes();
	void PlaceAllAssetsInScene();
	void ConvertLandscapesToStaticMeshes();
	static void DetachMultipleComponentActors();
	static void ConvertSplineMeshesToStaticActor( AActor* Actor );
	static void ConvertSplineMeshesAndDynamicMeshesToStaticActors();
	static void ConvertSkeletalMeshesToStaticActors();
	static void ConvertBrushesToStaticActors();
	static bool ConvertDynamicMeshToStaticMesh( FString NewAssetPath, UDynamicMeshComponent* DynamicMeshComponent, UStaticMesh*& OutStaticMesh );
	static bool ConvertProceduralMeshToStaticMesh( FString NewAssetPath, UProceduralMeshComponent* DynamicMeshComponent, UStaticMesh*& OutStaticMesh );
	void FixLandscapeMaterials();
	void PrepareForExport();
	static void DoPrepareForExport();
	void SpawnAllMaterialNodes();
	void RemoveSkinChunking();
	void BakeTextures();
	void GetTerrainData();

	TSharedPtr<FUICommandList> EditorCommands;
};


class FUnrealToUnity_Commands : public TCommands<FUnrealToUnity_Commands>
{
public:
	FUnrealToUnity_Commands()
		: TCommands<FUnrealToUnity_Commands>( "UnrealToUnityEditor", NSLOCTEXT( "Contexts", "UnrealToUnityEditor", "UnrealToUnityEditor" ), NAME_None, 
		#if ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION >= 1
			FAppStyle::GetAppStyleSetName()
		#else
			FEditorStyle::GetStyleSetName()
		#endif
		)
	{
	}

	TSharedPtr<FUICommandInfo> Export;
	TSharedPtr<FUICommandInfo> PlaceAllAssetsInScene;
	TSharedPtr<FUICommandInfo> ConvertLandscapesToStaticMeshes;
	TSharedPtr<FUICommandInfo> PrepareForExport;
	TSharedPtr<FUICommandInfo> SpawnAllMaterialNodes;
	TSharedPtr<FUICommandInfo> RemoveSkinChunking;
	TSharedPtr<FUICommandInfo> BakeTextures;
	TSharedPtr<FUICommandInfo> GetTerrainData;
	
	virtual void RegisterCommands() override;
};

void IterateOverAllAssetsOfType( FName TypeName, std::function<bool( FAssetData& )> lambda, bool SaveAndUnload = true );
void EnsureSettingsExists();
void GetOutputExpression( UMaterial* Material, UMaterialExpression* Source, int OutputIndex, TArray< FExpressionInput*>& Inputs );